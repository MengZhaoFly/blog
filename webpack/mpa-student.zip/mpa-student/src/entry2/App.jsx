import React, { useState } from 'react';

class App extends React.Component {
	render() {
		return (
			<div>this is entry 2</div>
		)
	}
}

export default App;