import React from 'react';
import ReactDOM from 'react-dom';

import App from './App';


ReactDOM.render(
	<div className="box">
		<App />
	</div> ,
	document.getElementById('app')
);